package org.kodigo.api.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONTACTS")
public class Contact {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    private long contact_id;
    private String first_Name;
    private String last_Name;
    private long type_contact_id;
    private long user_id;

    public Contact() {
    	
    }

	public Contact(long contact_id, String first_Name, String last_Name, long type_contact_id, long user_id) {
		super();
		this.contact_id = contact_id;
		this.first_Name = first_Name;
		this.last_Name = last_Name;
		this.type_contact_id = type_contact_id;
		this.user_id = user_id;
	}

	public long getContact_id() {
		return contact_id;
	}

	public void setContact_id(long contact_id) {
		this.contact_id = contact_id;
	}

	public String getFirst_Name() {
		return first_Name;
	}

	public void setFirst_Name(String first_Name) {
		this.first_Name = first_Name;
	}

	public String getLast_Name() {
		return last_Name;
	}

	public void setLast_Name(String last_Name) {
		this.last_Name = last_Name;
	}

	public long getType_contact_id() {
		return type_contact_id;
	}

	public void setType_contact_id(long type_contact_id) {
		this.type_contact_id = type_contact_id;
	}

	public long getUser_id() {
		return user_id;
	}

	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (contact_id ^ (contact_id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Contact other = (Contact) obj;
		if (contact_id != other.contact_id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Contact [contact_id=" + contact_id + ", first_Name=" + first_Name + ", last_Name=" + last_Name
				+ ", type_contact_id=" + type_contact_id + ", user_id=" + user_id + "]";
	}
    
    
}
