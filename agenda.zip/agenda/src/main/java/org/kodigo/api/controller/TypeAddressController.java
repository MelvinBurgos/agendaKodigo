package org.kodigo.api.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.kodigo.api.exception.ResourceNotFoundException;
import org.kodigo.api.model.TypeAddress;
import org.kodigo.api.repository.TypeAddressRepository;

@RestController
@RequestMapping("/api/v1")
public class TypeAddressController {

	@Autowired
	private TypeAddressRepository typeAddressRepository;
	
	@GetMapping("/typeAddresses")
	public List<TypeAddress> getAllTypeAddresss(){
		return typeAddressRepository.findAll();
	}
	
	@GetMapping("/typeAddress/{id}")
	public ResponseEntity<TypeAddress> getTypeAddressById(@PathVariable(value = "id") Long typeAddressId) 
			throws ResourceNotFoundException{
		
		TypeAddress typeAddress = typeAddressRepository.findById(typeAddressId).orElseThrow(
				()-> new ResourceNotFoundException("TypeAddress not found for this id: " + typeAddressId));
		
		return ResponseEntity.ok().body(typeAddress);
	}
	
	@PostMapping("/typeAddress")
	public TypeAddress createTypeAddress(@Valid @RequestBody TypeAddress typeAddress) {
		return typeAddressRepository.save(typeAddress);
	}
	
	@PutMapping("/typeAddress/{id}")
	public ResponseEntity<TypeAddress> updateTypeAddress(@PathVariable(value = "id") Long typeAddressId, 
			@Valid @RequestBody TypeAddress typeAddressDetails) throws ResourceNotFoundException{
		
		TypeAddress typeAddress = typeAddressRepository.findById(typeAddressId).orElseThrow(
				() -> new ResourceNotFoundException("TypeAddress not found for this id: " + typeAddressId));
		
		typeAddress.setType_address_name(typeAddressDetails.getType_address_name());
		
		final TypeAddress updateTypeAddress = typeAddressRepository.save(typeAddress);
		return ResponseEntity.ok(updateTypeAddress);
	}
	
	@DeleteMapping("/typeAddress/{id}")
	public Map<String, Boolean> deleteTypeAddress(@PathVariable(value = "id") Long typeAddressId) 
			throws ResourceNotFoundException{
		
		TypeAddress typeAddress = typeAddressRepository.findById(typeAddressId).orElseThrow( 
				()-> new ResourceNotFoundException("TypeAddress not found for this id: " + typeAddressId));
		
		typeAddressRepository.delete(typeAddress);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
