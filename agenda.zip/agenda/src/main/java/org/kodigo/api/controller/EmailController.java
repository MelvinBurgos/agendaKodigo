package org.kodigo.api.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.kodigo.api.exception.ResourceNotFoundException;
import org.kodigo.api.model.Email;
import org.kodigo.api.repository.EmailRepository;

@RestController
@RequestMapping("/api/v1")
public class EmailController {

	@Autowired
	private EmailRepository emailRepository;
	
	@GetMapping("/emails")
	public List<Email> getAllEmails(){
		return emailRepository.findAll();
	}
	
	@GetMapping("/email/{id}")
	public ResponseEntity<Email> getEmailById(@PathVariable(value = "id") Long emailId) 
			throws ResourceNotFoundException{
		
		Email email = emailRepository.findById(emailId).orElseThrow(
				()-> new ResourceNotFoundException("Email not found for this id: " + emailId));
		
		return ResponseEntity.ok().body(email);
	}
	
	@PostMapping("/email")
	public Email createEmail(@Valid @RequestBody Email email) {
		return emailRepository.save(email);
	}
	
	@PutMapping("/email/{id}")
	public ResponseEntity<Email> updateEmail(@PathVariable(value = "id") Long emailId, 
			@Valid @RequestBody Email emailDetails) throws ResourceNotFoundException{
		
		Email email = emailRepository.findById(emailId).orElseThrow(
				() -> new ResourceNotFoundException("Email not found for this id: " + emailId));
		
		email.setEmail(emailDetails.getEmail());
		email.setType_email_id(emailDetails.getType_email_id());
		
		final Email updateEmail = emailRepository.save(email);
		return ResponseEntity.ok(updateEmail);
	}
	
	@DeleteMapping("/email/{id}")
	public Map<String, Boolean> deleteEmail(@PathVariable(value = "id") Long emailId) 
			throws ResourceNotFoundException{
		
		Email email = emailRepository.findById(emailId).orElseThrow( 
				()-> new ResourceNotFoundException("Email not found for this id: " + emailId));
		
		emailRepository.delete(email);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
	
}
