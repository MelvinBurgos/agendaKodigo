package org.kodigo.api.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.kodigo.api.exception.ResourceNotFoundException;
import org.kodigo.api.model.Country;
import org.kodigo.api.repository.CountryRepository;

@RestController
@RequestMapping("/api/v1")
public class CountryController {

	@Autowired
	private CountryRepository countryRepository;
	
	@GetMapping("/countries")
	public List<Country> getAllCountrys(){
		return countryRepository.findAll();
	}
	
	@GetMapping("/country/{id}")
	public ResponseEntity<Country> getCountryByCode(@PathVariable(value = "id") Long countryCode) 
			throws ResourceNotFoundException{
		
		Country country = countryRepository.findById(countryCode).orElseThrow(
				()-> new ResourceNotFoundException("Country not found for this id: " + countryCode));
		
		return ResponseEntity.ok().body(country);
	}
	
	@PostMapping("/country")
	public Country createCountry(@Valid @RequestBody Country country) {
		return countryRepository.save(country);
	}
	
	@PutMapping("/country/{id}")
	public ResponseEntity<Country> updateCountry(@PathVariable(value = "id") Long countryCode, 
			@Valid @RequestBody Country countryDetails) throws ResourceNotFoundException{
		
		Country country = countryRepository.findById(countryCode).orElseThrow(
				() -> new ResourceNotFoundException("Country not found for this code: " + countryCode));
		
		country.setCountry_name(countryDetails.getCountry_name());
		
		final Country updateCountry = countryRepository.save(country);
		return ResponseEntity.ok(updateCountry);
	}
	
	@DeleteMapping("/country/{id}")
	public Map<String, Boolean> deleteCountry(@PathVariable(value = "id") Long countryCode) 
			throws ResourceNotFoundException{
		
		Country country = countryRepository.findById(countryCode).orElseThrow( 
				()-> new ResourceNotFoundException("Country not found for this id: " + countryCode));
		
		countryRepository.delete(country);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
