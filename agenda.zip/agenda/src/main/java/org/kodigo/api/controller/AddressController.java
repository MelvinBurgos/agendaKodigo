package org.kodigo.api.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.kodigo.api.exception.ResourceNotFoundException;
import org.kodigo.api.model.Address;
import org.kodigo.api.repository.AddressRepository;

@RestController
@RequestMapping("/api/v1")
public class AddressController {

	@Autowired
	private AddressRepository addressRepository;
	
	@GetMapping("/addresses")
	public List<Address> getAllAdresses(){
		return addressRepository.findAll();
	}
	
	@GetMapping("/address/{id}")
	public ResponseEntity<Address> getContactById(@PathVariable(value = "id") Long addressId) 
			throws ResourceNotFoundException{
		
		Address address = addressRepository.findById(addressId).orElseThrow(
				()-> new ResourceNotFoundException("Address not found for this id: " + addressId));
		
		return ResponseEntity.ok().body(address);
	}
	
	@PostMapping("/address")
	public Address createAddress(@Valid @RequestBody Address address) {
		return addressRepository.save(address);
	}
	
	@PutMapping("/address/{id}")
	public ResponseEntity<Address> updateAddress(@PathVariable(value = "id") Long addressId, 
			@Valid @RequestBody Address addressDetails) throws ResourceNotFoundException{
		
		Address address = addressRepository.findById(addressId).orElseThrow(
				() -> new ResourceNotFoundException("Address not found for this id: " + addressId));
		
		address.setCity(addressDetails.getCity());
		address.setZip(addressDetails.getZip());
		address.setState(addressDetails.getState());
		address.setCountry_code(addressDetails.getCountry_code());
		address.setOthers(addressDetails.getOthers());
		address.setContact_id(addressDetails.getContact_id());
		address.setType_address_id(addressDetails.getType_address_id());
		
		final Address updateAddress = addressRepository.save(address);
		return ResponseEntity.ok(updateAddress);
	}
	
	@DeleteMapping("/address/{id}")
	public Map<String, Boolean> deleteAddress(@PathVariable(value = "id") Long addressId) 
			throws ResourceNotFoundException{
		
		Address address = addressRepository.findById(addressId).orElseThrow( 
				()-> new ResourceNotFoundException("Contact not found for this id: " + addressId));
		
		addressRepository.delete(address);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
}
