package org.kodigo.api.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import org.kodigo.api.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

}
