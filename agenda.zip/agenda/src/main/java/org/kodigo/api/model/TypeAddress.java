package org.kodigo.api.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TYPE_ADDRESSES")
public class TypeAddress {
	
	@Id
	private long type_address_id;
	private String type_address_name;
	
	public TypeAddress() {
		
	}

	public TypeAddress(long type_address_id, String type_address_name) {
		super();
		this.type_address_id = type_address_id;
		this.type_address_name = type_address_name;
	}

	public long getType_address_id() {
		return type_address_id;
	}

	public void setType_address_id(long type_address_id) {
		this.type_address_id = type_address_id;
	}

	public String getType_address_name() {
		return type_address_name;
	}

	public void setType_address_name(String type_address_name) {
		this.type_address_name = type_address_name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (type_address_id ^ (type_address_id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TypeAddress other = (TypeAddress) obj;
		if (type_address_id != other.type_address_id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TypeAddress [type_address_id=" + type_address_id + ", type_address_name=" + type_address_name + "]";
	}

}
