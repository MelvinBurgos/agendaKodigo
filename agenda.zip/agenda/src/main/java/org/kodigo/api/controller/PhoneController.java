package org.kodigo.api.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.kodigo.api.exception.ResourceNotFoundException;
import org.kodigo.api.model.Phone;
import org.kodigo.api.repository.PhoneRepository;

@RestController
@RequestMapping("/api/v1")
public class PhoneController {

	@Autowired
	private PhoneRepository phoneRepository;
	
	@GetMapping("/phones")
	public List<Phone> getAllPhones(){
		return phoneRepository.findAll();
	}
	
	@GetMapping("/phone/{id}")
	public ResponseEntity<Phone> getPhoneById(@PathVariable(value = "id") Long phoneId) 
			throws ResourceNotFoundException{
		
		Phone phone = phoneRepository.findById(phoneId).orElseThrow(
				()-> new ResourceNotFoundException("Phone not found for this id: " + phoneId));
		
		return ResponseEntity.ok().body(phone);
	}
	
	@PostMapping("/phone")
	public Phone createPhone(@Valid @RequestBody Phone phone) {
		return phoneRepository.save(phone);
	}
	
	@PutMapping("/phone/{id}")
	public ResponseEntity<Phone> updatePhone(@PathVariable(value = "id") Long phoneId, 
			@Valid @RequestBody Phone phoneDetails) throws ResourceNotFoundException{
		
		Phone phone = phoneRepository.findById(phoneId).orElseThrow(
				() -> new ResourceNotFoundException("Phone not found for this id: " + phoneId));
		
		phone.setPhone_number(phoneDetails.getPhone_number());
		phone.setPhone_area(phoneDetails.getPhone_area());
		phone.setPhone_extension(phoneDetails.getPhone_extension());
		phone.setCountry_code(phoneDetails.getCountry_code());
		phone.setType_phone_id(phoneDetails.getType_phone_id());
		phone.setContact_id(phoneDetails.getContact_id());
		
		final Phone updatePhone = phoneRepository.save(phone);
		return ResponseEntity.ok(updatePhone);
	}
	
	@DeleteMapping("/phone/{id}")
	public Map<String, Boolean> deletePhone(@PathVariable(value = "id") Long phoneId) 
			throws ResourceNotFoundException{
		
		Phone phone = phoneRepository.findById(phoneId).orElseThrow( 
				()-> new ResourceNotFoundException("Phone not found for this id: " + phoneId));
		
		phoneRepository.delete(phone);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
