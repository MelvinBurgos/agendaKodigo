package org.kodigo.api.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.kodigo.api.exception.ResourceNotFoundException;
import org.kodigo.api.model.TypePhone;
import org.kodigo.api.repository.TypePhoneRepository;

@RestController
@RequestMapping("/api/v1")
public class TypePhoneController {

	@Autowired
	private TypePhoneRepository typePhoneRepository;
	
	@GetMapping("/typePhones")
	public List<TypePhone> getAllTypePhones(){
		return typePhoneRepository.findAll();
	}
	
	@GetMapping("/typePhone/{id}")
	public ResponseEntity<TypePhone> getTypePhoneById(@PathVariable(value = "id") Long typePhoneId) 
			throws ResourceNotFoundException{
		
		TypePhone typePhone = typePhoneRepository.findById(typePhoneId).orElseThrow(
				()-> new ResourceNotFoundException("TypePhone not found for this id: " + typePhoneId));
		
		return ResponseEntity.ok().body(typePhone);
	}
	
	@PostMapping("/typePhone")
	public TypePhone createTypePhone(@Valid @RequestBody TypePhone typePhone) {
		return typePhoneRepository.save(typePhone);
	}
	
	@PutMapping("/typePhone/{id}")
	public ResponseEntity<TypePhone> updateTypePhone(@PathVariable(value = "id") Long typePhoneId, 
			@Valid @RequestBody TypePhone typePhoneDetails) throws ResourceNotFoundException{
		
		TypePhone typePhone = typePhoneRepository.findById(typePhoneId).orElseThrow(
				() -> new ResourceNotFoundException("TypePhone not found for this id: " + typePhoneId));
		
		typePhone.setType_phone_name(typePhoneDetails.getType_phone_name());
		
		final TypePhone updateTypePhone = typePhoneRepository.save(typePhone);
		return ResponseEntity.ok(updateTypePhone);
	}
	
	@DeleteMapping("/typePhone/{id}")
	public Map<String, Boolean> deleteTypePhone(@PathVariable(value = "id") Long typePhoneId) 
			throws ResourceNotFoundException{
		
		TypePhone typePhone = typePhoneRepository.findById(typePhoneId).orElseThrow( 
				()-> new ResourceNotFoundException("TypePhone not found for this id: " + typePhoneId));
		
		typePhoneRepository.delete(typePhone);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
