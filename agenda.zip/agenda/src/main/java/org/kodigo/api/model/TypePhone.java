package org.kodigo.api.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TYPE_PHONES")
public class TypePhone {

	@Id
	private long type_phone_id;
	private String type_phone_name;
	
	public TypePhone() {
		
	}

	public TypePhone(long type_phone_id, String type_phone_name) {
		super();
		this.type_phone_id = type_phone_id;
		this.type_phone_name = type_phone_name;
	}

	public long getType_phone_id() {
		return type_phone_id;
	}

	public void setType_phone_id(long type_phone_id) {
		this.type_phone_id = type_phone_id;
	}

	public String getType_phone_name() {
		return type_phone_name;
	}

	public void setType_phone_name(String type_phone_name) {
		this.type_phone_name = type_phone_name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (type_phone_id ^ (type_phone_id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TypePhone other = (TypePhone) obj;
		if (type_phone_id != other.type_phone_id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TypePhone [type_phone_id=" + type_phone_id + ", type_phone_name=" + type_phone_name + "]";
	}
	
}
