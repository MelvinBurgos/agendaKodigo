package org.kodigo.api.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PHONES")
public class Phone {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    private long phone_id;
	private String phone_number;
	private String phone_area;
	private String phone_extension;
	private long country_code;
	private long contact_id;
	private long type_phone_id;
	
	public Phone() {
		
	}

	public Phone(long phone_id, String phone_number, String phone_area, String phone_extension, long country_code,
			long contact_id, long type_phone_id) {
		super();
		this.phone_id = phone_id;
		this.phone_number = phone_number;
		this.phone_area = phone_area;
		this.phone_extension = phone_extension;
		this.country_code = country_code;
		this.contact_id = contact_id;
		this.type_phone_id = type_phone_id;
	}

	public long getPhone_id() {
		return phone_id;
	}

	public void setPhone_id(long phone_id) {
		this.phone_id = phone_id;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public String getPhone_area() {
		return phone_area;
	}

	public void setPhone_area(String phone_area) {
		this.phone_area = phone_area;
	}

	public String getPhone_extension() {
		return phone_extension;
	}

	public void setPhone_extension(String phone_extension) {
		this.phone_extension = phone_extension;
	}

	public long getCountry_code() {
		return country_code;
	}

	public void setCountry_code(long country_code) {
		this.country_code = country_code;
	}

	public long getContact_id() {
		return contact_id;
	}

	public void setContact_id(long contact_id) {
		this.contact_id = contact_id;
	}

	public long getType_phone_id() {
		return type_phone_id;
	}

	public void setType_phone_id(long type_phone_id) {
		this.type_phone_id = type_phone_id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (phone_id ^ (phone_id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Phone other = (Phone) obj;
		if (phone_id != other.phone_id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Phone [phone_id=" + phone_id + ", phone_number=" + phone_number + ", phone_area=" + phone_area
				+ ", phone_extension=" + phone_extension + ", country_code=" + country_code + ", contact_id=" + contact_id
				+ ", type_phone_id=" + type_phone_id + "]";
	}

}
