package org.kodigo.api.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TYPE_CONTACTS")
public class TypeContact {
	
	@Id
	private long type_contact_id;
	private String type_contact_name;
	
	public TypeContact() {
		
	}

	public TypeContact(long type_contact_id, String type_contact_name) {
		super();
		this.type_contact_id = type_contact_id;
		this.type_contact_name = type_contact_name;
	}

	public long getType_contact_id() {
		return type_contact_id;
	}

	public void setType_contact_id(long type_contact_id) {
		this.type_contact_id = type_contact_id;
	}

	public String getType_contact_name() {
		return type_contact_name;
	}

	public void setType_contact_name(String type_contact_name) {
		this.type_contact_name = type_contact_name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (type_contact_id ^ (type_contact_id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TypeContact other = (TypeContact) obj;
		if (type_contact_id != other.type_contact_id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TypeContact [type_contact_id=" + type_contact_id + ", type_contact_name=" + type_contact_name + "]";
	}

}
