package org.kodigo.api.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import org.kodigo.api.model.TypeContact;

@Repository
public interface TypeContactRepository extends JpaRepository<TypeContact, Long> {

}
