package org.kodigo.api.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EMAILS")
public class Email {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    private long email_id;
	private String email;
	private long contact_id;
	private long type_email_id;
	
	public Email() {
		
	}

	public Email(long email_id, String email, long contact_id, long type_email_id) {
		super();
		this.email_id = email_id;
		this.email = email;
		this.contact_id = contact_id;
		this.type_email_id = type_email_id;
	}

	public long getEmail_id() {
		return email_id;
	}

	public void setEmail_id(long email_id) {
		this.email_id = email_id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getContact_id() {
		return contact_id;
	}

	public void setContact_id(long contact_id) {
		this.contact_id = contact_id;
	}

	public long getType_email_id() {
		return type_email_id;
	}

	public void setType_email_id(long type_email_id) {
		this.type_email_id = type_email_id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (email_id ^ (email_id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Email other = (Email) obj;
		if (email_id != other.email_id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Email [email_id=" + email_id + ", email=" + email + ", contact_id=" + contact_id + ", type_email_id="
				+ type_email_id + "]";
	}

}
