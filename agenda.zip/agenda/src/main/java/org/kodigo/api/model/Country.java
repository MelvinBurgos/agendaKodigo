package org.kodigo.api.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "COUNTRIES")
public class Country {
	
	@Id
    private long country_code;
	private String country_name;
	
	public Country() {
		
	}

	public Country(long country_code, String country_name) {
		super();
		this.country_code = country_code;
		this.country_name = country_name;
	}

	public long getCountry_code() {
		return country_code;
	}

	public void setCountry_code(long country_code) {
		this.country_code = country_code;
	}

	public String getCountry_name() {
		return country_name;
	}

	public void setCountry_name(String country_name) {
		this.country_name = country_name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (country_code ^ (country_code >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Country other = (Country) obj;
		if (country_code != other.country_code)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Country [country_code=" + country_code + ", country_name=" + country_name + "]";
	}

}
