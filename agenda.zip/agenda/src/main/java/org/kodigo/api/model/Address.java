package org.kodigo.api.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ADDRESSES")
public class Address {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    private long address_id;
	private String city;
	private String zip;
	private String state;
	private String others;
	private long country_code;
	private long contact_id;
	private long type_address_id;
	
	public Address() {
		
	}

	public Address(long address_id, String city, String zip, String state, String others, long country_code,
			long contact_id, long type_address_id) {
		super();
		this.address_id = address_id;
		this.city = city;
		this.zip = zip;
		this.state = state;
		this.others = others;
		this.country_code = country_code;
		this.contact_id = contact_id;
		this.type_address_id = type_address_id;
	}

	public long getAddress_id() {
		return address_id;
	}

	public void setAddress_id(long address_id) {
		this.address_id = address_id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getOthers() {
		return others;
	}

	public void setOthers(String others) {
		this.others = others;
	}

	public long getCountry_code() {
		return country_code;
	}

	public void setCountry_code(long country_code) {
		this.country_code = country_code;
	}

	public long getContact_id() {
		return contact_id;
	}

	public void setContact_id(long contact_id) {
		this.contact_id = contact_id;
	}

	public long getType_address_id() {
		return type_address_id;
	}

	public void setType_address_id(long type_address_id) {
		this.type_address_id = type_address_id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (address_id ^ (address_id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (address_id != other.address_id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Address [address_id=" + address_id + ", city=" + city + ", zip=" + zip + ", state=" + state
				+ ", others=" + others + ", country_code=" + country_code + ", contact_id=" + contact_id
				+ ", type_address_id=" + type_address_id + "]";
	}

}
