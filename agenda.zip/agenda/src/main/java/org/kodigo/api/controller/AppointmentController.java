package org.kodigo.api.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.kodigo.api.exception.ResourceNotFoundException;
import org.kodigo.api.model.Appointment;
import org.kodigo.api.repository.AppointmentRepository;

@RestController
@RequestMapping("/api/v1")
public class AppointmentController {

	@Autowired
	private AppointmentRepository appointmentRepository;
	
	@GetMapping("/appointments")
	public List<Appointment> getAllAppointments(){
		return appointmentRepository.findAll();
	}
	
	@GetMapping("/appointment/{id}")
	public ResponseEntity<Appointment> getAppointmentById(@PathVariable(value = "id") Long appointmentId) 
			throws ResourceNotFoundException{
		
		Appointment appointment = appointmentRepository.findById(appointmentId).orElseThrow(
				()-> new ResourceNotFoundException("Appointment not found for this id: " + appointmentId));
		
		return ResponseEntity.ok().body(appointment);
	}
	
	@PostMapping("/appointment")
	public Appointment createAppointment(@Valid @RequestBody Appointment appointment) {
		return appointmentRepository.save(appointment);
	}
	
	@PutMapping("/appointment/{id}")
	public ResponseEntity<Appointment> updateAppointment(@PathVariable(value = "id") Long appointmentId, 
			@Valid @RequestBody Appointment appointmentDetails) throws ResourceNotFoundException{
		
		Appointment appointment = appointmentRepository.findById(appointmentId).orElseThrow(
				() -> new ResourceNotFoundException("Appointment not found for this id: " + appointmentId));
		
		appointment.setAppointment_date(appointmentDetails.getAppointment_date());
		appointment.setAppointment_time(appointmentDetails.getAppointment_time());
		appointment.setNotes(appointmentDetails.getNotes());
		
		final Appointment updateAppointment = appointmentRepository.save(appointment);
		return ResponseEntity.ok(updateAppointment);
	}
	
	@DeleteMapping("/appointment/{id}")
	public Map<String, Boolean> deleteAppointment(@PathVariable(value = "id") Long appointmentId) 
			throws ResourceNotFoundException{
		
		Appointment appointment = appointmentRepository.findById(appointmentId).orElseThrow( 
				()-> new ResourceNotFoundException("Appointment not found for this id: " + appointmentId));
		
		appointmentRepository.delete(appointment);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
