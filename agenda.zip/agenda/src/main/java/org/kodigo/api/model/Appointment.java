package org.kodigo.api.model;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "APPOINTMENTS")
public class Appointment {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    private long appointment_id;
	private Date appointment_date;
	private Time appointment_time;
	private String notes;
	private long user_id;
	
	public Appointment() {
		
	}
	
	public Appointment(long appointment_id, Date appointment_date, Time appointment_time, String notes, long user_id) {
		super();
		this.appointment_id = appointment_id;
		this.appointment_date = appointment_date;
		this.appointment_time = appointment_time;
		this.notes = notes;
		this.user_id = user_id;
	}

	public long getAppointment_id() {
		return appointment_id;
	}

	public void setAppointment_id(long appointment_id) {
		this.appointment_id = appointment_id;
	}

	public Date getAppointment_date() {
		return appointment_date;
	}

	public void setAppointment_date(Date appointment_date) {
		this.appointment_date = appointment_date;
	}

	public Time getAppointment_time() {
		return appointment_time;
	}

	public void setAppointment_time(Time appointment_time) {
		this.appointment_time = appointment_time;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public long getUser_id() {
		return user_id;
	}

	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (appointment_id ^ (appointment_id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Appointment other = (Appointment) obj;
		if (appointment_id != other.appointment_id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Appointment [appointment_id=" + appointment_id + ", appointment_date=" + appointment_date
				+ ", appointment_time=" + appointment_time + ", notes=" + notes + ", user_id=" + user_id + "]";
	}

}
