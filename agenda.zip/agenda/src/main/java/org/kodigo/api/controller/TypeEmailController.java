package org.kodigo.api.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.kodigo.api.exception.ResourceNotFoundException;
import org.kodigo.api.model.TypeEmail;
import org.kodigo.api.repository.TypeEmailRepository;

@RestController
@RequestMapping("/api/v1")
public class TypeEmailController {

	@Autowired
	private TypeEmailRepository typeEmailRepository;
	
	@GetMapping("/typeEmails")
	public List<TypeEmail> getAllTypeEmails(){
		return typeEmailRepository.findAll();
	}
	
	@GetMapping("/typeEmail/{id}")
	public ResponseEntity<TypeEmail> getTypeEmailById(@PathVariable(value = "id") Long typeEmailId) 
			throws ResourceNotFoundException{
		
		TypeEmail typeEmail = typeEmailRepository.findById(typeEmailId).orElseThrow(
				()-> new ResourceNotFoundException("TypeEmail not found for this id: " + typeEmailId));
		
		return ResponseEntity.ok().body(typeEmail);
	}
	
	@PostMapping("/typeEmail")
	public TypeEmail createTypeEmail(@Valid @RequestBody TypeEmail typeEmail) {
		return typeEmailRepository.save(typeEmail);
	}
	
	@PutMapping("/typeEmail/{id}")
	public ResponseEntity<TypeEmail> updateTypeEmail(@PathVariable(value = "id") Long typeEmailId, 
			@Valid @RequestBody TypeEmail typeEmailDetails) throws ResourceNotFoundException{
		
		TypeEmail typeEmail = typeEmailRepository.findById(typeEmailId).orElseThrow(
				() -> new ResourceNotFoundException("TypeEmail not found for this id: " + typeEmailId));
		
		typeEmail.setType_email_name(typeEmailDetails.getType_email_name());
		
		final TypeEmail updateTypeEmail = typeEmailRepository.save(typeEmail);
		return ResponseEntity.ok(updateTypeEmail);
	}
	
	@DeleteMapping("/typeEmail/{id}")
	public Map<String, Boolean> deleteTypeEmail(@PathVariable(value = "id") Long typeEmailId) 
			throws ResourceNotFoundException{
		
		TypeEmail typeEmail = typeEmailRepository.findById(typeEmailId).orElseThrow( 
				()-> new ResourceNotFoundException("TypeEmail not found for this id: " + typeEmailId));
		
		typeEmailRepository.delete(typeEmail);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
