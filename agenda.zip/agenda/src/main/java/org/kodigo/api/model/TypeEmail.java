package org.kodigo.api.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TYPE_EMAILS")
public class TypeEmail {
	
	@Id
	private long type_email_id;
	private String type_email_name;
	
	public TypeEmail() {
		
	}

	public TypeEmail(long type_email_id, String type_email_name) {
		super();
		this.type_email_id = type_email_id;
		this.type_email_name = type_email_name;
	}

	public long getType_email_id() {
		return type_email_id;
	}

	public void setType_email_id(long type_email_id) {
		this.type_email_id = type_email_id;
	}

	public String getType_email_name() {
		return type_email_name;
	}

	public void setType_email_name(String type_email_name) {
		this.type_email_name = type_email_name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (type_email_id ^ (type_email_id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TypeEmail other = (TypeEmail) obj;
		if (type_email_id != other.type_email_id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TypeEmail [type_email_id=" + type_email_id + ", type_email_name=" + type_email_name + "]";
	}

}
