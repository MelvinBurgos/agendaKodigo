package org.kodigo.api.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.kodigo.api.exception.ResourceNotFoundException;
import org.kodigo.api.model.Contact;
import org.kodigo.api.repository.ContactRepository;

@RestController
@RequestMapping("/api/v1")
public class ContactController {

	@Autowired
	private ContactRepository contactRepository;
	
	@GetMapping("/contacts")
	public List<Contact> getAllContacts(){
		return contactRepository.findAll();
	}
	
	@GetMapping("/contact/{id}")
	public ResponseEntity<Contact> getContactById(@PathVariable(value = "id") Long contactId) 
			throws ResourceNotFoundException{
		
		Contact contact = contactRepository.findById(contactId).orElseThrow(
				()-> new ResourceNotFoundException("Contact not found for this id: " + contactId));
		
		return ResponseEntity.ok().body(contact);
	}
	
	@PostMapping("/contact")
	public Contact createContact(@Valid @RequestBody Contact contact) {
		return contactRepository.save(contact);
	}
	
	@PutMapping("/contact/{id}")
	public ResponseEntity<Contact> updateContact(@PathVariable(value = "id") Long contactId, 
			@Valid @RequestBody Contact contactDetails) throws ResourceNotFoundException{
		
		Contact contact = contactRepository.findById(contactId).orElseThrow(
				() -> new ResourceNotFoundException("Contact not found for this id: " + contactId));
		
		contact.setFirst_Name(contactDetails.getFirst_Name());
		contact.setLast_Name(contactDetails.getLast_Name());
		contact.setType_contact_id(contactDetails.getType_contact_id());
		
		final Contact updateContact = contactRepository.save(contact);
		return ResponseEntity.ok(updateContact);
	}
	
	@DeleteMapping("/contact/{id}")
	public Map<String, Boolean> deleteContact(@PathVariable(value = "id") Long contactId) 
			throws ResourceNotFoundException{
		
		Contact contact = contactRepository.findById(contactId).orElseThrow( 
				()-> new ResourceNotFoundException("Contact not found for this id: " + contactId));
		
		contactRepository.delete(contact);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
}
