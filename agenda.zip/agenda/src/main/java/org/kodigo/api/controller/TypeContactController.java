package org.kodigo.api.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.kodigo.api.exception.ResourceNotFoundException;
import org.kodigo.api.model.TypeContact;
import org.kodigo.api.repository.TypeContactRepository;

@RestController
@RequestMapping("/api/v1")
public class TypeContactController {

	@Autowired
	private TypeContactRepository typeContactRepository;
	
	@GetMapping("/typeContacts")
	public List<TypeContact> getAllTypeContacts(){
		return typeContactRepository.findAll();
	}
	
	@GetMapping("/typeContact/{id}")
	public ResponseEntity<TypeContact> getTypeContactById(@PathVariable(value = "id") Long typeContactId) 
			throws ResourceNotFoundException{
		
		TypeContact typeContact = typeContactRepository.findById(typeContactId).orElseThrow(
				()-> new ResourceNotFoundException("TypeContact not found for this id: " + typeContactId));
		
		return ResponseEntity.ok().body(typeContact);
	}
	
	@PostMapping("/typeContact")
	public TypeContact createTypeContact(@Valid @RequestBody TypeContact typeContact) {
		return typeContactRepository.save(typeContact);
	}
	
	@PutMapping("/typeContact/{id}")
	public ResponseEntity<TypeContact> updateTypeContact(@PathVariable(value = "id") Long typeContactId, 
			@Valid @RequestBody TypeContact typeContactDetails) throws ResourceNotFoundException{
		
		TypeContact typeContact = typeContactRepository.findById(typeContactId).orElseThrow(
				() -> new ResourceNotFoundException("TypeContact not found for this id: " + typeContactId));
		
		typeContact.setType_contact_name(typeContactDetails.getType_contact_name());
		
		final TypeContact updateTypeContact = typeContactRepository.save(typeContact);
		return ResponseEntity.ok(updateTypeContact);
	}
	
	@DeleteMapping("/typeContact/{id}")
	public Map<String, Boolean> deleteTypeContact(@PathVariable(value = "id") Long typeContactId) 
			throws ResourceNotFoundException{
		
		TypeContact typeContact = typeContactRepository.findById(typeContactId).orElseThrow( 
				()-> new ResourceNotFoundException("TypeContact not found for this id: " + typeContactId));
		
		typeContactRepository.delete(typeContact);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
